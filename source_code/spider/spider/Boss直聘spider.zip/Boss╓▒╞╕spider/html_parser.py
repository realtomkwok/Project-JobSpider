# -*- coding: utf-8 -*-
# @Time    : 2018/1/7 上午11:47
# @Author  : Mazy
# @File    : html_parser.py
# @Software: PyCharm

from bs4 import BeautifulSoup
import re
class HtmlParser(object):

    def parse(self, html_content):
        if html_content is None:
            return None

        soup = BeautifulSoup(html_content, 'html.parser')
        # 获取公司的列表
        companies = soup.find('div', class_='job-list').select('ul > li')

        results = []
        for com in companies:
            res = self.get_one_company(com)
            results.append(res)

        return results


    def get_one_company(self, soup):

        company_soup = soup.find('div', class_="info-company")
        # company name
        com_name = company_soup.find('a').text
        # company desc
        com_desc = company_soup.find('p').text


        primary_soup = soup.find('div', class_="info-primary")
        # job name
        all = primary_soup.find('h3', class_="name").a.text
        sala = primary_soup.find('h3', class_="name").a.span.text
        job = all.replace(sala, "")
        # salary
        salary = primary_soup.find('h3', class_="name").a.span.text
        # conpany require
        job_require = primary_soup.find('p').text
        match = re.search(r'([^\d]*)([经\d]*.*)',job_require)
        if match:
           city = match.group(1) 
        match_ = re.search(r'([^\d]*)(\d+.*)',com_desc)
        if match_:
            size = match_.group(2)
        else:
            size = 'null'
        exper = re.search(r'(.*[年限])(.*)',job_require)
        if exper: 
            major = exper.group(2)
        else:
            major = "null"
        exp = job_require.replace(city,"")
        expe_ = exp.replace(major,"")
        return [com_name, job, salary, city,size,major,expe_]

"""公司名称、职位名称、工资范围、经验（学历）要求、公司规模"""
 


